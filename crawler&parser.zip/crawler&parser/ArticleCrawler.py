#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys, os
import csv
import time
from random import randint
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import cookielib
import traceback
import requests

##########################################
###PLASE PROVIDE YOUR ACCOUNT INFORMATION
##########################################
sphaccount = ''
sphpassword = ''

###set working directory
os.chdir(os.getcwd()+'/Data')

def main(startline, endline):
    ###open input file, which contains article links
    input = open('links.csv')
    ###start crawler
    login_url = "http://www.straitstimes.com/premium/news/story/cupid-takes-aim-singles-over-40-20150405"
    
    crawler(login_url, input, startline, endline)

def crawler(login_url, infile, startline, endline):
    ##########################################
    ###PLEASE CHANGE THIS PATH ACCORDINGLY
    ##########################################
    browser = webdriver.Chrome('C:\Program Files (x86)\chromedriver')
    ###login in Chrome
    cookies = login(browser, login_url)
    ###open log file, which contains crawling logs
    log_file = open('crawler_log.csv', 'ab')
    log_writer = csv.writer(log_file, delimiter=',', quoting=csv.QUOTE_MINIMAL) 
    ###read the first line
    line = infile.readline().strip()
    ###store line number to determine where to start
    linenum = 1
    log_data = []
    while(line):
        ###go to intended lines, for multi-machine work
        if (linenum >= startline) & (linenum <= endline):
            connection_error = 0
            login_page = 0
            partial_content = 0
            write2disk = 0
            print '*****************************Processing line '+str(linenum)+'*****************************'
            ###remove space in front and behind
            article_infor = line.strip()
            ###get each field
            pieces = article_infor.split(',')
            article_id = pieces[0]
            article_url = pieces[1]

            print 'Article ' + str(article_id) +': ' + article_url 
            ###get html source
            [page_type, html] = get_html(cookies, article_url)
            ###error encountered in opening url
            if html=='':
                connection_error = 1
            ###no error
            else:
                connection_error = 0
                ###login page, no html file store
                if page_type == 1:                    
                    #login_page = 1
                    print 'invalid account login'
                    break 
                else:
                    ###store html file
                    outfile = open('html_'+str(article_id)+'.html', "w")
                    outfile.write(html.encode('utf-8'))
                    outfile.close()
                    write2disk = 1
                    ###premium webpage
                    if page_type == 2:
                        #partial_content = 1
                        print 'invalid account login'
                        ###Log in again, get new cookies
                        logout(browser)
                        cookies = login(browser, login_url)
                        continue
            ###record crawling log
            log_data.append([article_id, article_url, connection_error, login_page, partial_content, write2disk])
            ###write to disk for every 20 articles
            if (linenum-startline+1)%20 == 0:   
                log_writer.writerows(log_data)
                log_file.flush()
                log_data = []
        ###read in next line
        line = infile.readline()
        linenum = linenum + 1 
    ###append to log file
    log_writer.writerows(log_data)
    log_file.close()

def is_premium(url):
    return url.find('/premium/') != -1

def need_login(html):
    if html.find('To continue reading, log in if you are a subscriber') != -1:
        return 1
    else:
        return 0
        
def login(browser, login_url):    
    browser.get(login_url)
    browser.delete_all_cookies()
    # input_var = raw_input("Input 'yes' after secure login: ")
    # while input_var != 'yes':
        # input_var = raw_input("Input 'yes' after secure login: ")
    ###Login automatically
    elem = browser.find_element_by_id('Remember')
    elem.click()
    time.sleep(3)
    elem = browser.find_element_by_id('j_username')
    elem.send_keys(sphaccount)
    time.sleep(3)
    elem = browser.find_element_by_id('j_password')
    elem.send_keys(sphpassword+ Keys.RETURN)
    ###Delay for a while
    time.sleep(10)
    ###Get cookies from the response header
    cookie = browser.get_cookies()
    cookies = {}
    for s in cookie:
        cookies[s['name']] = s['value']
    print(cookies)     
    return cookies
 
def logout(browser):
    elem = browser.find_element_by_link_text('LOG OUT')
    elem.click()
    time.sleep(30)

def get_html(cookies, url):
    ###page_type: 0-normal page, 1-login page, 2-partial content to login
    page_type = 0
    header = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.111 Safari/537.36', 'Referer':'http://www.straitstimes.com/'}
    try:
        page = requests.get(url, cookies=cookies, timeout=8, headers=header)
    except Exception, e:
        exstr = traceback.format_exc()
        print exstr
        #print 'Got an error when request the webpage with the code',  
        html = ''
    else:
        ###get the source code of the page
        html = page.text
        if page.url.lower().find('regauth2') != -1:
            page_type = 1
        if need_login(html):
            page_type = 2
    ###random delay to mimic normal user
    #time.sleep(randint(1,5))
    return [page_type, html]
              
if __name__ == '__main__':
    if len(sys.argv) != 3:
        print 'Please input start and end lines!'
        print str(sys.argv)
        exit(1)
    main(int(sys.argv[1]), int(sys.argv[2]))
    #main()
