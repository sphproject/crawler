A) Given an existing list of article urls, ArticleCrawler.py helps you crawl htmls from the website of StaitsTimes, .

Preparation before running ArticleCrawler.py:
1. Supply the name and password of your StraitsTimes account by changing the values of sphaccount and sphpassword in the source code (lines 17 and 18).
2. Install selenium for Python and the browser driver for Chrome (please refer to http://www.seleniumhq.org/). Do remember change the path to Chrome driver accordingly in the source code (line 35).
3. Put the urls that you want to crawl into links.csv, which is under the folder "Data". Please notice that links.csv contains two columns without column names. The first column is the url id and the second one is the url per se. The url id is used to name the html file crawled.

To run ArticleCrawler.py, please change the directory of a cmd window to current folder and type "python ArticleCrawler.py [startline] [endline]" in the cmd. [startline] and [endline] are two parameters that tell the program where to start and where to end in the input file (links.csv).

After crawling:
1. The html files are stored under the folder "Data".
2. Do check the log file (crawler_log.csv) to know the working status of your crawler. Each url processed by the crawler has one entry in the log file. Each entry contains 6 fields. The first two are  article id and url. The following four are status codes, denoting whether any connection error encountered, whether the page is login page, whether the content is not complete due to login request and whether the html has been write to disk, respectively.

B) Given articles crawled, ContentExtraction.py helps you parse htmls, based on ST standard template.

1. All htmls are stored in the folder: /Data
2. Run the ContentExtraction.py, and enter the range of index for the target html files accordingly
3. There will be an output file in the /Data folder, which is the parsed outcome.
